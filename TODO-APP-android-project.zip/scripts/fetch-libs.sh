#!/usr/bin/env bash
# Downloads the JavaScript libraries the website loads from CDNs and points index.html at the local copies,
# so the app also works offline. Every download is optional: if one fails, that library keeps using its CDN link.
set -u
ASSETS="$(cd "$(dirname "$0")/.." && pwd)/app/src/main/assets"
LIBS="$ASSETS/libs"
HTML="$ASSETS/index.html"
mkdir -p "$LIBS/fonts"

get() {  # get <url> <local file name>
  local url="$1" name="$2"
  if curl -fsSL --retry 3 --max-time 120 "$url" -o "$LIBS/$name"; then
    # rewrite the link (plain and JSON-escaped forms)
    python3 - "$HTML" "$url" "/libs/$name" <<'PY'
import sys
p, old, new = sys.argv[1:4]
s = open(p, encoding='utf-8').read()
s = s.replace(old, new)
open(p, 'w', encoding='utf-8').write(s)
PY
    echo "local: $name"
  else
    rm -f "$LIBS/$name"
    echo "WARNING: could not download $url (CDN link kept)"
  fi
}

get "https://cdn.jsdelivr.net/npm/chart.js"                                         chart.js
get "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"                  katex.min.js
get "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"    katex-auto-render.min.js
get "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"          jspdf.umd.min.js
get "https://unpkg.com/vue@3/dist/vue.global.js"                                    vue.global.js
get "https://cdn.tailwindcss.com"                                                   tailwind.js
get "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"             jszip.min.js
get "https://cdnjs.cloudflare.com/ajax/libs/mathjax/3.2.2/es5/tex-svg.js"          mathjax-tex-svg.js
get "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"            pdf.min.js
get "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"     pdf.worker.min.js

# KaTeX stylesheet + its fonts
if curl -fsSL --retry 3 "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css" -o "$LIBS/katex.min.css"; then
  ok=1
  for f in $(grep -o 'fonts/[A-Za-z0-9_-]*\.woff2' "$LIBS/katex.min.css" | sort -u); do
    curl -fsSL --retry 3 "https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/$f" -o "$LIBS/$f" || ok=0
  done
  if [ "$ok" = 1 ]; then
    python3 - "$HTML" <<'PY'
import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
s = s.replace("https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css", "/libs/katex.min.css")
open(p, 'w', encoding='utf-8').write(s)
PY
    echo "local: katex.min.css + fonts"
  else
    echo "WARNING: KaTeX fonts incomplete (CDN link kept)"
  fi
fi
echo "done"
