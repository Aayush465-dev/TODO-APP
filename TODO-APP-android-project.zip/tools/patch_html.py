#!/usr/bin/env python3
"""Turns the original single-file website into app/src/main/assets/index.html
(desktop-site viewport, floating focus controller, native PDF saving hooks).
Run:  python3 tools/patch_html.py original/Index_-_Cvvopy.html app/src/main/assets/index.html
"""
import json, re, sys

src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf-8').read()

m = re.search(r'(<script id="jmt-site-source" type="application/json">)(.*?)(</script>)', s, re.S)
assert m, 'embedded test site not found'
site = json.loads(m.group(2))
main = s[:m.start()] + '@@SITE@@' + s[m.end():]


def sub1(text, old, new, label, regex=False):
    if regex:
        out, n = re.subn(old, lambda _m: new, text, count=0, flags=re.S)
    else:
        n = text.count(old)
        out = text.replace(old, new)
    assert n == 1, f'{label}: expected 1 match, found {n}'
    return out


# ---------------------------------------------------------------- main page
# 1. desktop-site viewport (same idea as "Desktop site" in a mobile browser)
VIEWPORT = '<meta name="viewport" content="width=1024, minimum-scale=0.1, maximum-scale=5, user-scalable=yes">'
main, n = re.subn(r'<meta name="viewport"[^>]*>', VIEWPORT, main)
assert n >= 1, 'viewport'

# 2. native bridge script
main = sub1(main, '<head>', '<head>\n    <script src="/native-bridge.js"></script>', 'head')

# 3. Float buttons
main = sub1(
    main,
    '<button id="btn-maximize-focus" style="background:#8b5cf6; padding:8px 16px; border-radius:20px;">Maximize ⛶</button>',
    '<button id="btn-maximize-focus" style="background:#8b5cf6; padding:8px 16px; border-radius:20px;">Maximize ⛶</button>\n'
    '            <button id="btn-float" class="float-btn" onclick="toggleFloat()" style="background:#f59e0b; padding:8px 16px; border-radius:20px;">🪟 Float</button>',
    'float bar button')
main = sub1(
    main,
    '<button id="btn-focus-minimize" style="background:rgba(71, 85, 105, 0.9);">↙ Minimize</button>',
    '<button id="btn-focus-minimize" style="background:rgba(71, 85, 105, 0.9);">↙ Minimize</button>\n'
    '                <button id="btn-float-fs" class="float-btn" onclick="toggleFloat()" style="background:#f59e0b;">🪟 Float</button>',
    'float fs button')

# 4. settings (Manage Tasks modal + focus screen settings popup)
FLOAT_OPTIONS = ('<option value="all_today">Today\'s total – all tasks (default)</option>'
                 '<option value="task_today">Today\'s total – running task</option>'
                 '<option value="task_total">Task total – running task (all days)</option>')
anchor = re.search(r'id="last-backup-text"></div>\s*</div>', main)
assert anchor, 'backup block anchor'
manage_block = (
    '\n\n        <div class="android-only" style="background:var(--surface); padding:15px; border-radius:8px; margin-top:15px; '
    'text-align:left; border:1px solid var(--border-color);">\n'
    '            <h4 style="margin-top:0; color:var(--text-main);">Floating Controller</h4>\n'
    '            <label style="display:block; font-size:13px; color:var(--text-muted); margin-bottom:6px;">Time shown on the floating button:</label>\n'
    '            <select class="float-mode-select" onchange="saveFloatSettings(this.value)" style="width:100%;">' + FLOAT_OPTIONS + '</select>\n'
    '        </div>')
main = main[:anchor.end()] + manage_block + main[anchor.end():]

main = sub1(
    main,
    '<button onclick="editFocusTimeFs()" style="background:transparent; border:1px solid #94a3b8; color:#f8fafc; width:100%; margin-top:15px;">✏️ Edit Focus Time</button>',
    '<button onclick="editFocusTimeFs()" style="background:transparent; border:1px solid #94a3b8; color:#f8fafc; width:100%; margin-top:15px;">✏️ Edit Focus Time</button>\n'
    '                <div class="android-only" style="margin-top:15px;"><label style="color:#94a3b8; font-size:13px; display:block; margin-bottom:5px;">Floating button shows:</label>'
    '<select class="float-mode-select" onchange="saveFloatSettings(this.value)" style="width:100%; background:#0f172a; color:white; border:1px solid #475569;">'
    + FLOAT_OPTIONS + '</select></div>',
    'fs settings')

# 5. focus tick must be callable from native code + fix a latent bug (undefined variable at midnight)
main = sub1(main, 'let focusInterval = null; let lastFocusTick = null;',
            'let focusInterval = null; let lastFocusTick = null; let focusTickFn = null;', 'focusTickFn decl')
tick_start = re.search(r'focusInterval = setInterval\(\(\) => \{(\s*let now = Date\.now\(\); let delta = now - lastFocusTick;)', main)
assert tick_start, 'tick start'
main = main[:tick_start.start()] + 'focusTickFn = () => {' + tick_start.group(1) + main[tick_start.end():]
tick_end = re.search(r'\}, 1000\);(\s*\}\s*function pauseFocus\(\))', main)
assert tick_end, 'tick end'
main = main[:tick_end.start()] + '}; focusInterval = setInterval(focusTickFn, 1000);' + tick_end.group(1) + main[tick_end.end():]
_i = main.index('focusTickFn = () =>')
_j = main.index('currentFocus.totalElapsed += actualSecsAdded;', _i)
main = main[:_j] + 'currentFocus.totalElapsed += actualAdded;' + main[_j + len('currentFocus.totalElapsed += actualSecsAdded;'):]

# 6. floating controller logic
FLOAT_BLOCK = r'''
<style>
.float-btn{display:none}
html.android-app .float-btn{display:inline-block}
.android-only{display:none!important}
html.android-app .android-only{display:block!important}
</style>
<script>
/* ================= FLOATING FOCUS CONTROLLER (Android app) ================= */
(function () {
  const B = window.AndroidBridge || null;
  let floatOn = false;
  const MODE_LABEL = { all_today: "today's total of all tasks", task_today: "today's total of the running task", task_total: "total of the running task" };

  function hasTask() { return !!(currentFocus && (currentFocus.taskId || currentFocus.spId)); }

  /* which time the floating button shows (setting: appSettings.floatMode) */
  function floatSeconds() {
    const mode = appSettings.floatMode || 'all_today';
    const today = getLocalToday();
    if (mode === 'all_today' || !hasTask()) return getTotalFocus(today);
    if (currentFocus.type === 'regular') {
      const t = tasks.find(x => x.id === currentFocus.taskId);
      if (!t || !t.dailyFocus) return 0;
      if (mode === 'task_today') return t.dailyFocus[today] || 0;
      return Object.values(t.dailyFocus).reduce((a, b) => a + b, 0);
    }
    const sp = specialTasks.find(x => x.id === currentFocus.spId);
    if (!sp || !sp.focus) return 0;
    if (mode === 'task_today') return (sp.focus[today] && sp.focus[today][currentFocus.subId]) || 0;
    let sum = 0;
    Object.values(sp.focus).forEach(day => { sum += (day && day[currentFocus.subId]) || 0; });
    return sum;
  }

  function floatState() {
    const nameEl = document.getElementById('active-task-name');
    return { name: hasTask() && nameEl ? nameEl.innerText : 'No task', active: !!currentFocus.active, sec: floatSeconds(), ts: Date.now(), hasTask: hasTask() };
  }
  function pushFloat() {
    if (!B || !floatOn) return;
    try { B.focusState(JSON.stringify(floatState())); } catch (e) {}
  }
  function refreshFloatButtons() {
    document.querySelectorAll('.float-btn').forEach(b => {
      b.innerText = floatOn ? '🪟 Float: ON' : '🪟 Float';
      b.style.background = floatOn ? '#10b981' : '#f59e0b';
    });
  }

  /* ---- settings ---- */
  window.syncFloatSettingsUI = function () {
    document.querySelectorAll('.float-mode-select').forEach(s => { s.value = appSettings.floatMode || 'all_today'; });
  };
  window.saveFloatSettings = function (v) {
    appSettings.floatMode = MODE_LABEL[v] ? v : 'all_today';
    localStorage.setItem('utmxSettings', JSON.stringify(appSettings));
    window.syncFloatSettingsUI();
    pushFloat();
    showToast('Floating button shows ' + MODE_LABEL[appSettings.floatMode]);
  };
  document.addEventListener('DOMContentLoaded', () => { window.syncFloatSettingsUI(); refreshFloatButtons(); });

  if (!B) return;

  /* keep the floating button in sync with the timer */
  const _updateFocusUI = window.updateFocusUI;
  window.updateFocusUI = function () { const r = _updateFocusUI.apply(this, arguments); pushFloat(); return r; };
  const _completeFocus = window.completeFocus;
  window.completeFocus = function () { const r = _completeFocus.apply(this, arguments); pushFloat(); return r; };

  /* ---- called from native code ---- */
  window.__nativeTick = function () {
    try { if (currentFocus.active && typeof focusTickFn === 'function') focusTickFn(); } catch (e) { console.error(e); }
    pushFloat();
  };
  window.__nativeFloatCmd = function (cmd) {
    try {
      if (cmd === 'toggle') toggleMainFocus();
      else if (cmd === 'pause') pauseFocus();
      else if (cmd === 'resume') resumeFocus();
    } catch (e) { console.error(e); }
    pushFloat();
  };
  window.__nativeFloatClosed = function () { floatOn = false; refreshFloatButtons(); };

  /* ---- the "Float" button ---- */
  window.toggleFloat = function () {
    if (floatOn) {
      try { B.stopFloat(); } catch (e) {}
      floatOn = false; refreshFloatButtons(); showToast('Floating timer closed');
      return;
    }
    if (!hasTask()) { showToast('Start focusing on a task first, then tap Float.'); return; }
    let r = 'error';
    try { r = B.startFloat(JSON.stringify(floatState())); } catch (e) {}
    if (r === 'ok') { floatOn = true; refreshFloatButtons(); }
    else if (r === 'permission') showToast('Turn on "Display over other apps" for TODO APP, then tap Float again.');
    else showToast('Could not start the floating timer.');
  };
})();
</script>
'''
main = main.replace('@@SITE@@', FLOAT_BLOCK + '\n    <script id="jmt-site-source" type="application/json">@@SITE@@</script>', 1)

# ---------------------------------------------------------------- embedded test website
site = sub1(site, '<head>', '<head>\n<script src="/native-bridge.js"></script>', 'site head')
site = sub1(
    site,
    "window.addEventListener('afterprint',rs,{once:true});window.print();setTimeout(rs,60000);break}",
    "window.addEventListener('afterprint',rs,{once:true});"
    "if(window.__nativePrintReport){window.__nativePrintReport(nm);setTimeout(rs,2000)}else{window.print();setTimeout(rs,60000)}break}",
    'report print')
gen = re.search(r"bar\.style\.width=Math\.round\(\(i\+1\)/list\.length\*100\)\+'%'\}\s*st\.textContent='';", site)
assert gen, 'generator anchor'
site = (site[:gen.end()]
        + "if(window.__nativeSave){for(const r of res){try{await window.__nativeSave(r.blob,r.nm,'questions')}catch(e){console.error(e)}}}"
        + site[gen.end():])

site_json = json.dumps(site, ensure_ascii=True).replace('<', '\\u003c')
out = main.replace('@@SITE@@', site_json, 1)
assert '@@SITE@@' not in out
open(dst, 'w', encoding='utf-8').write(out)
print('written', dst, len(out), 'bytes')
