# TODO APP (Android)

Your website packed as an Android app (WebView). Package: `com.todoapp.focus`.

## Build the APK (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab -> **Build TODO APP (APK)** -> **Run workflow** (it also runs on every push).
3. When it finishes, open the run and download the artifact **TODO-APP-apk** -> `TODO-APP.apk`. Install it on the phone.

Android Studio also works: open this folder, Build > Build APK(s).
The workflow downloads the JS libraries (Chart.js, KaTeX, jsPDF, PDF.js, MathJax, Vue, Tailwind...) into the app so it works offline.
The APK is signed with the key in `app/todoapp.jks`, so new builds install over old ones and keep your data.

## What is different from the website
* **Desktop-site mode is always on** (desktop user agent, 1024 px wide layout, pinch to zoom).
* **Float button** (bottom focus bar and focus screen). Tap it -> the app goes to the background and a floating controller is drawn over other apps:
  * time + **pause/resume**, **move** (drag handle) and **close**
  * closing always asks: **Pause focus** or **Keep going**
  * after 3 s untouched it turns dull and hides the time; tap it to show the time and solid colour again
  * first use asks for "Display over other apps" permission
* **Setting** (Manage Tasks > Floating Controller, and focus screen > Settings): time shown on the floating button
  * Today's total - all tasks (default)
  * Today's total - running task
  * Task total - running task (all days)
* **PDFs**
  * Every PDF you give the test website is copied to app-private storage (`files/test_pdfs/`). The app never deletes them.
  * Generated question PDFs are saved to `Download/PDFs/Questions/`, performance reports to `Download/PDFs/Reports/`.
  * Backups/other exports go to `Download/TODO APP/`.

## Notes
* App data (tasks, tests) lives inside the app. To move data from your browser, export a backup there and import it here.
* Back button sends the app to the background (timers keep running).
* `tools/patch_html.py` rebuilds `app/src/main/assets/index.html` from `original/Index_-_Cvvopy.html`.
