package android.print;

import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;

import java.io.File;

/**
 * Writes the content of a WebView print adapter straight into a PDF file (no print dialog).
 * It lives in the android.print package because the framework callbacks have package-private constructors.
 */
public final class PdfWriter {
    public interface Callback {
        void onDone(boolean ok, String error);
    }

    private PdfWriter() {}

    public static void write(final PrintDocumentAdapter adapter, final File out, final Callback cb) {
        try {
            final PrintAttributes attrs = new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("pdf", "pdf", 300, 300))
                    .setMinMargins(new PrintAttributes.Margins(300, 300, 300, 300))
                    .build();
            adapter.onStart();
            adapter.onLayout(null, attrs, new CancellationSignal(), new PrintDocumentAdapter.LayoutResultCallback() {
                @Override
                public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                    try {
                        final ParcelFileDescriptor fd = ParcelFileDescriptor.open(out,
                                ParcelFileDescriptor.MODE_READ_WRITE | ParcelFileDescriptor.MODE_CREATE
                                        | ParcelFileDescriptor.MODE_TRUNCATE);
                        adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, fd, new CancellationSignal(),
                                new PrintDocumentAdapter.WriteResultCallback() {
                                    @Override
                                    public void onWriteFinished(PageRange[] pages) {
                                        try { fd.close(); } catch (Exception ignored) {}
                                        try { adapter.onFinish(); } catch (Exception ignored) {}
                                        cb.onDone(true, null);
                                    }

                                    @Override
                                    public void onWriteFailed(CharSequence error) {
                                        try { fd.close(); } catch (Exception ignored) {}
                                        cb.onDone(false, String.valueOf(error));
                                    }

                                    @Override
                                    public void onWriteCancelled() {
                                        try { fd.close(); } catch (Exception ignored) {}
                                        cb.onDone(false, "cancelled");
                                    }
                                });
                    } catch (Throwable t) {
                        cb.onDone(false, String.valueOf(t));
                    }
                }

                @Override
                public void onLayoutFailed(CharSequence error) {
                    cb.onDone(false, String.valueOf(error));
                }

                @Override
                public void onLayoutCancelled() {
                    cb.onDone(false, "cancelled");
                }
            }, null);
        } catch (Throwable t) {
            cb.onDone(false, String.valueOf(t));
        }
    }
}
