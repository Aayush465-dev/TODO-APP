package com.todoapp.focus;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** Exposed to JavaScript as window.AndroidBridge */
public class JsBridge {
    private static final String TAG = "TodoApp";

    private static class Session {
        String category, name, mime;
        File part;
        FileOutputStream out;
    }

    private final MainActivity act;
    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<Integer, Session> sessions = new ConcurrentHashMap<>();
    private final AtomicInteger ids = new AtomicInteger(1);
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    JsBridge(MainActivity activity) {
        this.act = activity;
        this.app = activity.getApplicationContext();
    }

    // ------------------------------------------------------------------ misc
    @JavascriptInterface
    public boolean isAndroidApp() { return true; }

    @JavascriptInterface
    public void toast(final String msg) {
        main.post(new Runnable() {
            @Override public void run() { Toast.makeText(app, msg, Toast.LENGTH_SHORT).show(); }
        });
    }

    @JavascriptInterface
    public void keepScreenOn(final boolean on) {
        main.post(new Runnable() {
            @Override public void run() {
                if (on) act.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
    }

    // ------------------------------------------------------------------ floating controller
    @JavascriptInterface
    public boolean hasOverlayPermission() { return Settings.canDrawOverlays(app); }

    /** @return "ok", "permission" or "error" */
    @JavascriptInterface
    public String startFloat(final String stateJson) {
        if (!Settings.canDrawOverlays(app)) {
            main.post(new Runnable() {
                @Override public void run() {
                    Toast.makeText(app, "Allow \"Display over other apps\" for TODO APP, then tap Float again",
                            Toast.LENGTH_LONG).show();
                    try {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.getPackageName()));
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        act.startActivity(i);
                    } catch (Exception e) { Log.w(TAG, "overlay settings", e); }
                }
            });
            return "permission";
        }
        main.post(new Runnable() {
            @Override public void run() {
                try {
                    Intent i = new Intent(app, FloatingService.class);
                    i.putExtra("state", stateJson);
                    app.startForegroundService(i);
                    // go to the home screen so the user can open any other app; the floating timer stays on top
                    main.postDelayed(new Runnable() {
                        @Override public void run() { act.moveTaskToBack(true); }
                    }, 350);
                } catch (Exception e) { Log.w(TAG, "start float", e); }
            }
        });
        return "ok";
    }

    @JavascriptInterface
    public void focusState(final String stateJson) { FloatingService.pushState(stateJson); }

    @JavascriptInterface
    public void stopFloat() { FloatingService.requestStop(app); }

    // ------------------------------------------------------------------ saving files (chunked)
    @JavascriptInterface
    public int saveBegin(String category, String name, String mime) {
        try {
            Session s = new Session();
            s.category = category == null ? "other" : category;
            s.name = name == null ? "file" : name;
            s.mime = mime;
            int id = ids.getAndIncrement();
            s.part = new File(app.getCacheDir(), "save_" + id + ".part");
            s.out = new FileOutputStream(s.part);
            sessions.put(id, s);
            return id;
        } catch (IOException e) {
            Log.w(TAG, "saveBegin", e);
            return -1;
        }
    }

    @JavascriptInterface
    public void saveChunk(int id, String base64) {
        Session s = sessions.get(id);
        if (s == null || s.out == null) return;
        try {
            s.out.write(Base64.decode(base64, Base64.DEFAULT));
        } catch (Exception e) { Log.w(TAG, "saveChunk", e); }
    }

    @JavascriptInterface
    public void saveEnd(int id) {
        final Session s = sessions.remove(id);
        if (s == null) return;
        try { s.out.close(); } catch (IOException ignored) {}
        worker.execute(new Runnable() {
            @Override public void run() { finish(s); }
        });
    }

    private void finish(final Session s) {
        try {
            String name = FileStore.safeName(s.name, "file");
            if ("report_html".equals(s.category)) {
                renderReport(s, name);
                return;
            }
            String sub = "reports".equals(s.category) ? FileStore.DIR_REPORTS
                    : "questions".equals(s.category) ? FileStore.DIR_QUESTIONS : FileStore.DIR_OTHER;
            String mime = FileStore.mimeFor(name);
            if ("application/octet-stream".equals(mime) && s.mime != null && !s.mime.isEmpty()) mime = s.mime;
            announce(FileStore.saveToDownloads(app, s.part, sub, name, mime));
        } catch (Throwable t) {
            Log.w(TAG, "save failed", t);
            FileStore.toast(app, "Could not save file: " + t.getMessage());
        } finally {
            if (!"report_html".equals(s.category)) //noinspection ResultOfMethodCallIgnored
                s.part.delete();
        }
    }

    private void announce(String result) {
        if (result.startsWith("EXISTS:")) FileStore.toast(app, "Already saved in " + result.substring(7));
        else FileStore.toast(app, "Saved in " + result);
    }

    private void renderReport(final Session s, final String name) throws IOException {
        final StringBuilder html = new StringBuilder();
        FileInputStream in = new FileInputStream(s.part);
        try {
            byte[] buf = new byte[64 * 1024];
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            html.append(bos.toString("UTF-8"));
        } finally { in.close(); }
        //noinspection ResultOfMethodCallIgnored
        s.part.delete();

        final String pdfName = name.toLowerCase().endsWith(".pdf") ? name : name + ".pdf";
        final File tmpPdf = new File(app.getCacheDir(), "report_" + System.nanoTime() + ".pdf");
        main.post(new Runnable() {
            @Override public void run() {
                ReportPdf.render(act, html.toString(), pdfName, tmpPdf, new ReportPdf.Done() {
                    @Override public void onFinished(final File pdf, final String error) {
                        if (pdf == null) {
                            if (!"FALLBACK".equals(error)) FileStore.toast(app, "Report PDF failed: " + error);
                            return;
                        }
                        worker.execute(new Runnable() {
                            @Override public void run() {
                                try {
                                    announce(FileStore.saveToDownloads(app, pdf, FileStore.DIR_REPORTS, pdfName, "application/pdf"));
                                } catch (Throwable t) {
                                    FileStore.toast(app, "Could not save report: " + t.getMessage());
                                } finally {
                                    //noinspection ResultOfMethodCallIgnored
                                    pdf.delete();
                                }
                            }
                        });
                    }
                });
            }
        });
    }
}
