package com.todoapp.focus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

/**
 * "Draw over other apps" focus controller.
 *  - solid bar: time + pause/resume + move + close
 *  - after 3 seconds without touching it, it turns dull and hides the time (small faded dot)
 *  - tap the dot -> time and solid colour are back (and fade again after 3 s)
 *  - close -> asks every time: pause the focus or keep it going
 */
public class FloatingService extends Service {
    private static final String CHANNEL = "float_focus";
    private static final int NOTIF_ID = 4711;
    private static final long DIM_AFTER_MS = 3000;

    private static FloatingService inst;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private FrameLayout root;
    private LinearLayout bar;
    private View dot;
    private LinearLayout confirm;
    private TextView timeText, titleText;
    private GlyphView btnToggle, btnMove, btnClose;
    private GradientDrawable barBg, dotBg;
    private PowerManager.WakeLock wakeLock;
    private SharedPreferences prefs;

    // state mirrored from the web page
    private String taskName = "No task";
    private boolean active = false, hasTask = false;
    private long baseSec = 0, baseTs = System.currentTimeMillis();

    private boolean dull = false, confirming = false, notifyJsOnExit = true;
    private float density;

    private final Runnable dimRunnable = new Runnable() {
        @Override public void run() { setDull(true); }
    };
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (MainActivity.instance == null) { stopSelf(); return; }   // app was closed
            refreshTime();
            if (active) MainActivity.evalJs("window.__nativeTick&&window.__nativeTick()");
            h.postDelayed(this, 1000);
        }
    };

    // ------------------------------------------------------------------ static helpers used by JsBridge
    static void pushState(final String json) {
        final FloatingService s = inst;
        if (s == null) return;
        s.h.post(new Runnable() { @Override public void run() { s.applyState(json); } });
    }

    static void requestStop(Context c) {
        final FloatingService s = inst;
        if (s != null) {
            s.notifyJsOnExit = false;
            s.h.post(new Runnable() { @Override public void run() { s.stopSelf(); } });
        }
    }

    // ------------------------------------------------------------------ service lifecycle
    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        density = getResources().getDisplayMetrics().density;
        prefs = getSharedPreferences("float", MODE_PRIVATE);
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Floating focus timer", NotificationManager.IMPORTANCE_LOW));
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Focus timer is floating")
                .setContentText("Tap to open TODO APP")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(NOTIF_ID, n);

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "todoapp:float");
        wakeLock.acquire(6 * 60 * 60 * 1000L);

        buildOverlay();
        h.postDelayed(tick, 1000);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("state")) applyState(intent.getStringExtra("state"));
        wake();
        return START_NOT_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        notifyJsOnExit = false;
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        h.removeCallbacksAndMessages(null);
        try { if (root != null) wm.removeView(root); } catch (Exception ignored) {}
        try { if (wakeLock != null && wakeLock.isHeld()) wakeLock.release(); } catch (Exception ignored) {}
        if (notifyJsOnExit) MainActivity.evalJs("window.__nativeFloatClosed&&window.__nativeFloatClosed()");
        if (inst == this) inst = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ state
    private void applyState(String json) {
        try {
            JSONObject o = new JSONObject(json);
            taskName = o.optString("name", "No task");
            active = o.optBoolean("active", false);
            hasTask = o.optBoolean("hasTask", true);
            baseSec = o.optLong("sec", 0);
            baseTs = o.optLong("ts", System.currentTimeMillis());
            if (active && wakeLock != null && !wakeLock.isHeld()) wakeLock.acquire(6 * 60 * 60 * 1000L);
        } catch (Exception ignored) { return; }
        refreshAll();
    }

    private long currentSec() {
        long s = baseSec;
        if (active) s += Math.max(0, (System.currentTimeMillis() - baseTs) / 1000);
        return s;
    }

    private static String fmt(long s) {
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
    }

    // ------------------------------------------------------------------ UI
    private int dp(float v) { return Math.round(v * density); }

    private void buildOverlay() {
        root = new FrameLayout(this);

        // ---- solid bar: time + 3 buttons
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14), dp(4), dp(8), dp(4));
        barBg = new GradientDrawable();
        barBg.setCornerRadius(dp(28));
        bar.setBackground(barBg);

        timeText = new TextView(this);
        timeText.setTextColor(Color.WHITE);
        timeText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timeText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        timeText.setText("00:00:00");
        bar.addView(timeText, new LinearLayout.LayoutParams(ViewGroupLP.WRAP, ViewGroupLP.WRAP));

        btnToggle = new GlyphView(this, GlyphView.PAUSE);
        btnMove = new GlyphView(this, GlyphView.MOVE);
        btnClose = new GlyphView(this, GlyphView.CLOSE);
        int b = dp(40);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(b, b);
        blp.leftMargin = dp(4);
        bar.addView(btnToggle, blp);
        bar.addView(btnMove, blp);
        bar.addView(btnClose, blp);

        btnToggle.setOnClickListener(v -> { wake(); onToggle(); });
        btnClose.setOnClickListener(v -> showConfirm());
        btnMove.setOnTouchListener(new DragListener(true));

        // ---- dull dot (shown after 3 s without touch)
        dot = new View(this);
        dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dot.setBackground(dotBg);
        dot.setOnTouchListener(new DragListener(false));

        // ---- close confirmation
        confirm = new LinearLayout(this);
        confirm.setOrientation(LinearLayout.VERTICAL);
        confirm.setPadding(dp(16), dp(14), dp(16), dp(12));
        GradientDrawable cbg = new GradientDrawable();
        cbg.setColor(0xFF1F2937);
        cbg.setCornerRadius(dp(18));
        confirm.setBackground(cbg);
        titleText = new TextView(this);
        titleText.setTextColor(Color.WHITE);
        titleText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titleText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleText.setText("Close floating timer?");
        confirm.addView(titleText);
        TextView sub = new TextView(this);
        sub.setTextColor(0xFFB6C0D0);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        sub.setText("Pause the focus, or keep it going?");
        sub.setPadding(0, dp(2), 0, dp(10));
        confirm.addView(sub);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        TextView bPause = pill("Pause focus", 0xFFEF4444);
        TextView bKeep = pill("Keep going", 0xFF10B981);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, ViewGroupLP.WRAP, 1f);
        pl.rightMargin = dp(8);
        row.addView(bPause, pl);
        row.addView(bKeep, new LinearLayout.LayoutParams(0, ViewGroupLP.WRAP, 1f));
        confirm.addView(row);
        TextView cancel = new TextView(this);
        cancel.setText("Cancel");
        cancel.setTextColor(0xFFB6C0D0);
        cancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, dp(10), 0, dp(2));
        confirm.addView(cancel);
        confirm.setVisibility(View.GONE);

        bPause.setOnClickListener(v -> {
            MainActivity.evalJs("window.__nativeFloatCmd&&window.__nativeFloatCmd('pause')");
            closeFloat();
        });
        bKeep.setOnClickListener(v -> closeFloat());
        cancel.setOnClickListener(v -> hideConfirm());

        root.addView(bar);
        root.addView(dot, new FrameLayout.LayoutParams(dp(44), dp(44)));
        root.addView(confirm, new FrameLayout.LayoutParams(dp(250), ViewGroupLP.WRAP));
        dot.setVisibility(View.GONE);

        lp = new WindowManager.LayoutParams(
                ViewGroupLP.WRAP, ViewGroupLP.WRAP,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = prefs.getInt("x", dp(24));
        lp.y = prefs.getInt("y", dp(160));
        try {
            wm.addView(root, lp);
        } catch (Exception e) {   // overlay permission missing / revoked
            notifyJsOnExit = true;
            stopSelf();
            return;
        }
        refreshAll();
        wake();
    }

    private TextView pill(String text, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(9), dp(6), dp(9));
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(20));
        t.setBackground(g);
        return t;
    }

    private int stateColor() { return active ? 0xFF16A34A : 0xFFD97706; }

    private void refreshAll() {
        int c = stateColor();
        barBg.setColor(c);
        dotBg.setColor(c);
        btnToggle.setType(active ? GlyphView.PAUSE : GlyphView.PLAY);
        btnToggle.setAlpha(hasTask ? 1f : 0.4f);
        refreshTime();
    }

    private void refreshTime() {
        if (timeText != null) timeText.setText(fmt(currentSec()));
    }

    private void onToggle() {
        if (!hasTask) return;
        // optimistic update; the web page confirms with its own state a moment later
        baseSec = currentSec();
        baseTs = System.currentTimeMillis();
        active = !active;
        refreshAll();
        MainActivity.evalJs("window.__nativeFloatCmd&&window.__nativeFloatCmd('toggle')");
    }

    /** Solid & full-size again, then dull after 3 seconds of no touch. */
    private void wake() {
        setDull(false);
        h.removeCallbacks(dimRunnable);
        if (!confirming) h.postDelayed(dimRunnable, DIM_AFTER_MS);
    }

    private void setDull(boolean d) {
        dull = d;
        if (confirming) return;
        if (d) {
            bar.setVisibility(View.GONE);
            dot.setVisibility(View.VISIBLE);
            root.setAlpha(0.35f);
        } else {
            dot.setVisibility(View.GONE);
            bar.setVisibility(View.VISIBLE);
            root.setAlpha(1f);
        }
        clampToScreen();
    }

    private void showConfirm() {
        confirming = true;
        h.removeCallbacks(dimRunnable);
        root.setAlpha(1f);
        bar.setVisibility(View.GONE);
        dot.setVisibility(View.GONE);
        confirm.setVisibility(View.VISIBLE);
        clampToScreen();
    }

    private void hideConfirm() {
        confirming = false;
        confirm.setVisibility(View.GONE);
        bar.setVisibility(View.VISIBLE);
        wake();
    }

    private void closeFloat() {
        // tell the page the floating timer is gone, then remove it (focus keeps running unless it was paused)
        notifyJsOnExit = true;
        stopSelf();
    }

    // ------------------------------------------------------------------ dragging
    private void moveTo(int x, int y) {
        lp.x = x;
        lp.y = y;
        clampToScreen();
        try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
    }

    private void clampToScreen() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        int w = root.getWidth() > 0 ? root.getWidth() : dp(120);
        int hh = root.getHeight() > 0 ? root.getHeight() : dp(48);
        lp.x = Math.max(0, Math.min(lp.x, dm.widthPixels - w));
        lp.y = Math.max(0, Math.min(lp.y, dm.heightPixels - hh));
        root.post(new Runnable() {
            @Override public void run() {
                try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
            }
        });
    }

    private final class DragListener implements View.OnTouchListener {
        private final boolean alwaysDrag;       // move button: always drags; dot: tap expands, drag moves
        private float downX, downY;
        private int startX, startY;
        private boolean dragging;
        private final int slop = ViewConfiguration.get(FloatingService.this).getScaledTouchSlop();

        DragListener(boolean alwaysDrag) { this.alwaysDrag = alwaysDrag; }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startX = lp.x;
                    startY = lp.y;
                    dragging = alwaysDrag;
                    v.setPressed(true);
                    if (alwaysDrag) wake();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) dragging = true;
                    if (dragging) {
                        moveTo(startX + Math.round(dx), startY + Math.round(dy));
                        if (alwaysDrag) wake();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    if (dragging) prefs.edit().putInt("x", lp.x).putInt("y", lp.y).apply();
                    else if (!alwaysDrag && e.getActionMasked() == MotionEvent.ACTION_UP) wake();   // tap on the dull dot
                    return true;
                default:
                    return true;
            }
        }
    }

    private static final class ViewGroupLP {
        static final int WRAP = android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
    }
}
