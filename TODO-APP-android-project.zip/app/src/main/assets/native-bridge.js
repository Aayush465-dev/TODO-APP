/* TODO APP - native bridge (loaded in the main page AND in the embedded test-website frame).
   Does nothing in a normal browser. */
(function () {
  var B = null;
  try { B = window.AndroidBridge || (window.parent && window.parent.AndroidBridge) || null; } catch (e) {}
  if (!B) return;

  window.__isAndroidApp = true;
  try { document.documentElement.classList.add('android-app'); } catch (e) {}

  /* ---- Element fullscreen is not available inside the app: the focus screen already covers the page ---- */
  try {
    var rej = function () { return Promise.reject(new Error('fullscreen not supported in app')); };
    Element.prototype.requestFullscreen = rej;
    Element.prototype.webkitRequestFullscreen = rej;
  } catch (e) {}

  /* ---- "Screen On" fallback (Screen Wake Lock API is missing in WebView) ---- */
  try {
    if (!navigator.wakeLock) {
      navigator.wakeLock = {
        request: function () {
          B.keepScreenOn(true);
          var sentinel = {
            released: false,
            release: function () { B.keepScreenOn(false); sentinel.released = true; return Promise.resolve(); },
            addEventListener: function () {}
          };
          return Promise.resolve(sentinel);
        }
      };
    }
  } catch (e) {}

  /* ---- send a Blob to native code in small base64 chunks ---- */
  var CHUNK = 600 * 1024; /* multiple of 3 -> every chunk is valid base64 on its own */
  function readChunk(blob) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onload = function () { res(String(fr.result).split(',')[1] || ''); };
      fr.onerror = function () { rej(fr.error); };
      fr.readAsDataURL(blob);
    });
  }
  async function sendBlob(blob, name, category, mime) {
    var id = B.saveBegin(category, name, mime || blob.type || 'application/octet-stream');
    for (var off = 0; off < blob.size; off += CHUNK) {
      B.saveChunk(id, await readChunk(blob.slice(off, off + CHUNK)));
    }
    B.saveEnd(id);
  }
  window.__nativeSave = sendBlob;

  function categoryFor(name) {
    if (/\.pdf$/i.test(name)) return /^report/i.test(name) ? 'reports' : 'questions';
    if (/\.zip$/i.test(name) && /pdf|question/i.test(name)) return 'questions';
    return 'other';
  }

  /* ---- downloads created with <a download href="blob:..."> are saved by the app ---- */
  async function nativeDownload(href, name) {
    try {
      var r = await fetch(href);
      var b = await r.blob();
      name = name || 'download';
      await sendBlob(b, name, categoryFor(name), b.type);
    } catch (e) {
      console.error(e);
      try { B.toast('Download failed: ' + (e && e.message ? e.message : e)); } catch (x) {}
    }
  }
  try {
    var origClick = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
      if (this.hasAttribute('download') && /^(blob:|data:)/i.test(this.href)) {
        nativeDownload(this.href, this.getAttribute('download'));
        return;
      }
      return origClick.apply(this, arguments);
    };
    document.addEventListener('click', function (e) {
      var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
      if (a && /^(blob:|data:)/i.test(a.href)) {
        e.preventDefault();
        e.stopPropagation();
        nativeDownload(a.href, a.getAttribute('download'));
      }
    }, true);
  } catch (e) {}

  /* ---- Performance report: turn the page into a PDF and save it in Download/PDFs/Reports ---- */
  function blobToDataUrl(b) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onload = function () { res(fr.result); };
      fr.onerror = function () { rej(fr.error); };
      fr.readAsDataURL(b);
    });
  }
  window.__nativePrintReport = async function (name) {
    try {
      B.toast('Creating report PDF...');
      var root = document.documentElement.cloneNode(true);
      var live = Array.prototype.slice.call(document.querySelectorAll('#v-report img'));
      var copy = Array.prototype.slice.call(root.querySelectorAll('#v-report img'));
      for (var i = 0; i < live.length; i++) {
        var s = live[i].currentSrc || live[i].src;
        if (!s || /^data:/i.test(s)) continue;
        try {
          var r = await fetch(s);
          copy[i].setAttribute('src', await blobToDataUrl(await r.blob()));
        } catch (e) {}
      }
      Array.prototype.forEach.call(root.querySelectorAll('script,noscript'), function (n) { n.remove(); });
      var t = root.querySelector('title');
      if (t) t.textContent = name;
      var html = '<!DOCTYPE html>' + root.outerHTML;
      var file = String(name).replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim() || 'report';
      await sendBlob(new Blob([html], { type: 'text/html' }), file + '.pdf', 'report_html', 'text/html');
    } catch (e) {
      console.error(e);
      try { B.toast('Could not create the report PDF'); } catch (x) {}
    }
  };
})();
